package com.zecadev.outervoice;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(15, 23, 28), SURFACE = Color.rgb(24, 35, 41);
    private static final int TEAL = Color.rgb(0, 198, 199), MUTED = Color.rgb(174, 188, 199);
    private static final int LINE = Color.rgb(48, 65, 74), WHITE = Color.rgb(246, 249, 250);
    private static final int MIC_REQUEST = 10, STORAGE_REQUEST = 12;
    private final Handler main = new Handler();
    private final ArrayList<Sound> sounds = new ArrayList<>();
    private final ArrayList<TextView> rows = new ArrayList<>();
    private final ArrayList<View> bars = new ArrayList<>();
    private final ArrayList<TextView> settingsSummaries = new ArrayList<>();
    private String settingsSignature = "";
    private long settingsRefreshedAt;
    private ArrayList<Sound> editDraft;
    private ScrollView editScroll;
    private Typeface icons;
    private Typeface bodyFont;
    private LiveMicPassthrough live;
    private WavPlayer player;
    private VoiceSession speech;
    private boolean speechAnimating;
    private final Runnable speechChanged = this::onSpeechChanged;
    private void onSpeechChanged() { if (!paused) updateHome(); }
    private final WavRecorder recorder = new WavRecorder(this);
    private boolean holdingMic;
    private File temporaryRecording;
    private int recordEpoch;
    private long recordMilliseconds;
    private TextView addRecord, recordInfo;
    private File browseDirectory;
    private AudioManager audioManager;
    private AudioFocusRequest focus;
    private boolean hasFocus, paused, importing;
    private String page = "home", playingId = "", feedback = "";
    private String lastHomeState = "";
    private LinearLayout root;
    private TextView micButton, micLabel, micStatus, routeStatus, importLabel, saveButton;
    private EditText nameInput;
    private File pendingFile;
    private double level;
    private float scale = 1f;
    private volatile int importEpoch;
    private TextView previewPlay;
    private final Runnable refresh = new Runnable() {
        @Override public void run() {
            updateHome(); updatePreview(); updateSettings();
            if (!live.isActive() && !player.active() && !recorder.active()) abandonFocus();
            if (!paused) main.postDelayed(this, 120);
        }
    };
    private static final class Sound {
        final String id;
        String name;
        Sound(String id, String name) { this.id = id; this.name = name; }
    }

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN);
        scale = Math.min(getResources().getDisplayMetrics().widthPixels / 1024f,
                getResources().getDisplayMetrics().heightPixels / 600f);
        icons = Typeface.createFromAsset(getAssets(), "MaterialIcons-Regular.ttf");
        bodyFont = Typeface.createFromAsset(getAssets(), "Inter.ttf");
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        focus = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setOnAudioFocusChangeListener(change -> {
                    if (change < 0) { stopAudio(); feedback = "Audio interrupted"; updateHome(); }
                }, main).build();
        live = new LiveMicPassthrough(this, new LiveMicPassthrough.Listener() {
            @Override public void onStatus(String message) {
                main.post(() -> {
                    if (message.contains("failed")) feedback = message;
                    else if (message.contains("Starting")) feedback = "Starting…";
                    else feedback = "";
                    updateHome();
                });
            }
            @Override public void onLevel(double rms) { main.post(() -> level = rms); }
        });
        player = new WavPlayer(this);
        speech = VoiceSession.get(this); speech.observers.add(speechChanged);
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        live.setGain(preferences().getInt("mic_gain", 100) / 100f);
        cleanupTemporary();
        loadSounds();
        if ("buttons".equals(getIntent().getStringExtra("tab"))) showSmartButtons(); else showHome();
    }

    private int px(float value) { return Math.round(value * scale); }
    private LinearLayout column() { LinearLayout v = new LinearLayout(this); v.setOrientation(LinearLayout.VERTICAL); return v; }
    private LinearLayout row() { LinearLayout v = new LinearLayout(this); v.setOrientation(LinearLayout.HORIZONTAL); v.setGravity(Gravity.CENTER_VERTICAL); return v; }
    private TextView text(String value, float size, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(value); v.setTextColor(color);
        v.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(size));
        v.setTypeface(Typeface.create(bodyFont, bold ? Typeface.BOLD : Typeface.NORMAL));
        v.setGravity(Gravity.CENTER_VERTICAL); return v;
    }
    private TextView icon(String code, float size, int color) {
        TextView v = text(code, size, color, false); v.setTypeface(icons); v.setGravity(Gravity.CENTER); return v;
    }
    private GradientDrawable shape(int fill, int stroke, float radius, boolean circle) {
        GradientDrawable d = new GradientDrawable(); d.setColor(fill);
        if (circle) d.setShape(GradientDrawable.OVAL); else d.setCornerRadius(px(radius));
        if (stroke != 0) d.setStroke(px(circle ? 5 : 1), stroke); return d;
    }
    private void clickable(View view, int fill, int stroke, float radius, boolean circle) {
        view.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.argb(70, 255, 255, 255)),
                shape(fill, stroke, radius, circle), null));
        view.setClickable(true); view.setFocusable(true);
    }
    private TextView button(String label, boolean primary) {
        TextView v = text(label, 22, WHITE, true); v.setGravity(Gravity.CENTER);
        clickable(v, primary ? TEAL : SURFACE, primary ? 0 : LINE, 10, false);
        v.setPadding(px(20), 0, px(20), 0); return v;
    }
    private void space(LinearLayout parent, int height) { parent.addView(new View(this), new LinearLayout.LayoutParams(1, px(height))); }
    private LinearLayout startPage(String title, boolean back) {
        root = column(); root.setBackgroundColor(BG); setContentView(root);
        LinearLayout header = row(); header.setPadding(px(26), 0, px(26), 0);
        header.setBackgroundColor(SURFACE);
        root.addView(header, new LinearLayout.LayoutParams(-1, px(68)));
        if (back) {
            TextView arrow = icon("\ue5c4", 32, WHITE); arrow.setContentDescription("Back");
            clickable(arrow, Color.TRANSPARENT, 0, 8, false);
            header.addView(arrow, new LinearLayout.LayoutParams(px(56), px(56)));
            arrow.setOnClickListener(v -> cancelAdd());
        }
        TextView heading = text(title, 34, WHITE, true);
        if (!back) {
            SpannableString styled = new SpannableString(title);
            styled.setSpan(new ForegroundColorSpan(TEAL), 6, title.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            heading.setText(styled);
        }
        header.addView(heading, new LinearLayout.LayoutParams(0, -1, 1f));
        return header;
    }
    private void addTabs(boolean settings) {
        LinearLayout tabs = row(); tabs.setPadding(px(24), px(6), px(24), px(6));
        for (int i = 0; i < 2; i++) {
            final boolean settingsTab = i == 1;
            TextView tab = button(i == 0 ? "傳聲／聲音" : "設定", settingsTab == settings);
            tab.setSelected(settingsTab == settings);
            tab.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(19));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(px(174), px(48)); p.rightMargin = px(12); tabs.addView(tab,p);
            tab.setOnClickListener(v -> { stopAudio(); if (settingsTab) showSettings(); else showHome(); });
        }
        root.addView(tabs,new LinearLayout.LayoutParams(-1,px(60)));
    }
    private LinearLayout mainHeader() {
        LinearLayout header=startPage("Outer Voice",false);
        boolean available=AudioRoutes.outer(this)!=null;
        routeStatus=text(available?"Outer speaker":"Speaker unavailable",18,available?WHITE:MUTED,true);
        header.addView(routeStatus,new LinearLayout.LayoutParams(px(170),px(48)));
        TextView exit=icon("\ue8ac",30,WHITE);exit.setContentDescription("Exit app");
        clickable(exit,Color.TRANSPARENT,0,8,false);header.addView(exit,new LinearLayout.LayoutParams(px(48),px(48)));
        exit.setOnClickListener(v->{
            FloatingConfig.prefs(this).edit().putBoolean("enabled",false).putBoolean("minimized",false).commit();
            stopService(new Intent(this,FloatingPanelService.class));SmartButtonsService.command(this,SmartButtonsService.STOP);
            speech.cancel();stopAudio();importEpoch++;if(pendingFile!=null)pendingFile.delete();pendingFile=null;
            deleteTemporary();finishAndRemoveTask();
        });
        return header;
    }
    private void settingsBack(LinearLayout header) {
        TextView back=button("返回設定",false);back.setTextSize(TypedValue.COMPLEX_UNIT_PX,px(18));
        LinearLayout.LayoutParams position=new LinearLayout.LayoutParams(px(132),px(48));position.rightMargin=px(16);
        header.addView(back,0,position);
        back.setOnClickListener(v->showSettings());
    }
    private TextView settingsRow(LinearLayout parent,String glyph,String title,String value,Runnable action) {
        LinearLayout line=row();line.setPadding(px(18),0,px(14),0);clickable(line,SURFACE,0,0,false);
        line.addView(icon(glyph,28,TEAL),new LinearLayout.LayoutParams(px(44),-1));
        TextView label=text(title,21,WHITE,true);label.setPadding(px(12),0,0,0);
        line.addView(label,new LinearLayout.LayoutParams(px(260),-1));
        TextView summary=text(value,17,MUTED,false);summary.setMaxLines(2);summary.setEllipsize(android.text.TextUtils.TruncateAt.END);
        line.addView(summary,new LinearLayout.LayoutParams(0,-1,1));
        line.addView(icon("\ue5cc",26,MUTED),new LinearLayout.LayoutParams(px(32),-1));
        line.setContentDescription(title);line.setOnClickListener(v->action.run());parent.addView(line,new LinearLayout.LayoutParams(-1,px(64)));
        View divider=new View(this);divider.setBackgroundColor(LINE);parent.addView(divider,new LinearLayout.LayoutParams(-1,px(1)));
        return summary;
    }
    private LinearLayout settingsContent() {
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout content=column();content.setPadding(px(24),px(12),px(24),px(12));scroll.addView(content);return content;
    }
    private void showSettings() {
        page="settings";settingsSummaries.clear();settingsSignature="";settingsRefreshedAt=0;
        mainHeader();addTabs(true);LinearLayout content=settingsContent();
        settingsSummaries.add(settingsRow(content,"\ue029","傳聲方式","",this::selectSpeakingMode));
        settingsSummaries.add(settingsRow(content,"\ue31d","Live 麥克風","",this::showLiveSettings));
        settingsSummaries.add(settingsRow(content,"\ue050","音量及增益","",this::showAudioSettings));
        settingsSummaries.add(settingsRow(content,"\ue913","懸浮面板","",()->{stopAudio();startActivity(new Intent(this,FloatingButtonsActivity.class));}));
        settingsSummaries.add(settingsRow(content,"\ue1a7","靈動貼","",this::showSmartButtons));
        settingsSummaries.add(settingsRow(content,"\ue8b8","測試及關於","",this::showChecks));
        TextView note=text("畫面及懸浮按鈕共用傳聲方式；靈動貼單擊動作獨立設定。",16,MUTED,false);
        note.setPadding(px(8),px(6),px(8),0);content.addView(note,new LinearLayout.LayoutParams(-1,px(44)));
        updateSettings();FloatingPanelService.sync(this,false);
    }
    private void updateSettings() {
        if(!"settings".equals(page)||settingsSummaries.size()!=6)return;
        long now=android.os.SystemClock.elapsedRealtime();if(now-settingsRefreshedAt<500)return;settingsRefreshedAt=now;
        String microphone;try{microphone=LiveAudioConfig.label(LiveAudioConfig.input(this),0);}catch(RuntimeException e){microphone="已存麥克風離線";}
        SharedPreferences p=SpeakingOptions.prefs(this),floating=FloatingConfig.prefs(this);
        String[] values={SpeakingOptions.MODES[SpeakingOptions.mode(this)],
            LiveCaptureMode.label(LiveAudioConfig.mode(this))+" · "+microphone+" · +"+p.getInt("live_mic_db",0)+" dB",
            "系統 "+audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)+"/"+audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)+" · 車外 +"+p.getInt("external_db",0)+" dB",
            (floating.getBoolean("enabled",false)?"已啟用":"已關閉")+" · 按鈕 "+floating.getInt("size",88)+" px · 縮小 "+floating.getInt("minimized_size",88)+" px",
            (SmartButtonStore.prefs(this).getBoolean("enabled",false)?"已啟用":"已關閉")+" · "+SmartButtonStore.devices(this).size()+" 個靈動貼 · 配對及單擊／雙擊設定",
            "喇叭試音、音訊診斷、版本及授權"};
        String signature=java.util.Arrays.toString(values);if(signature.equals(settingsSignature))return;settingsSignature=signature;
        for(int i=0;i<values.length;i++)settingsSummaries.get(i).setText(values[i]);
    }
    private void showChecks() {
        page="checks";LinearLayout header=mainHeader();settingsBack(header);addTabs(true);
        LinearLayout content=settingsContent();content.addView(text("測試及關於",26,WHITE,true),new LinearLayout.LayoutParams(-1,px(52)));
        settingsRow(content,"\ue050","喇叭試音","測試車外喇叭輸出",this::testSpeaker);
        settingsRow(content,"\ue85c","音訊診斷","收音電平、音訊裝置及最近狀態",this::showDiagnostics);
        settingsRow(content,"\ue88e","關於及授權","Outer Voice 版本、製作及開源聲明",this::showCredits);
    }
    private void testSpeaker() {
        if(speech.busy()||live.isActive()||recorder.active()||player.active()){toast("請先停止目前音訊");return;}
        try{playFile(WavTools.testTone(getCacheDir()),"test");}catch(Exception e){toast(e.getMessage());}
    }
    private void showSmartButtons() {
        FloatingPanelService.sync(this,false);
        page = "buttons";LinearLayout header=mainHeader();settingsBack(header);addTabs(true);
        root.addView(new SmartButtonsPage(this),new LinearLayout.LayoutParams(-1,0,1));
    }
    private void selectSpeakingMode() {
        new AlertDialog.Builder(this).setTitle("畫面及懸浮按鈕收音模式")
            .setSingleChoiceItems(SpeakingOptions.MODES,SpeakingOptions.mode(this),(d,w)->{
                speech.cancelIfOwned(this); SpeakingOptions.prefs(this).edit().putInt("screen_mode",w).apply();
                FloatingPanelService.sync(this,true); d.dismiss(); if("settings".equals(page))showSettings();else showHome();
            }).setNegativeButton("取消",null).show();
    }
    private void showHome() {
        HoldFeedback.stop(micButton); speechAnimating = false;
        page = "home"; rows.clear(); bars.clear(); lastHomeState = "";
        mainHeader();
        addTabs(false);
        LinearLayout body = row(); body.setGravity(Gravity.TOP);
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout left = column(); left.setGravity(Gravity.CENTER_HORIZONTAL);
        left.setPadding(px(24), px(22), px(24), px(22));
        body.addView(left, new LinearLayout.LayoutParams(px(400), -1));
        String[] modeNames={"按住說話","點按錄音","即時傳聲"};
        TextView speakingMode = text("傳聲方式 · "+modeNames[SpeakingOptions.mode(this)],20,MUTED,false);
        left.addView(speakingMode,new LinearLayout.LayoutParams(-1,px(48)));
        LinearLayout controls = column(); controls.setGravity(Gravity.CENTER);
        left.addView(controls, new LinearLayout.LayoutParams(-1, 0, 1f));
        micButton = icon("\ue029", 100, TEAL);
        clickable(micButton, Color.TRANSPARENT, TEAL, 0, true);
        controls.addView(micButton, new LinearLayout.LayoutParams(px(160), px(160)));
        micButton.setOnTouchListener((v,event) -> {
            int mode = SpeakingOptions.mode(this);
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (microphoneAllowed()) { player.stop(); playingId = ""; feedback = ""; speech.down(this,mode); }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (microphoneAllowed()) speech.up(this,mode); v.performClick(); return true;
                case MotionEvent.ACTION_CANCEL: speech.cancelIfOwned(this); return true;
                default: return true;
            }
        });
        space(controls, 6);
        micLabel = text("Hold to Speak", 25, WHITE, true); micLabel.setGravity(Gravity.CENTER);
        controls.addView(micLabel, new LinearLayout.LayoutParams(-1, px(45)));
        space(controls, 5);
        LinearLayout meter = row(); meter.setGravity(Gravity.CENTER);
        for (int i = 0; i < 11; i++) {
            View bar = new View(this); bar.setBackground(shape(LINE, 0, 4, false));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(px(10), px(35));
            params.setMargins(px(4), 0, px(4), 0); meter.addView(bar, params); bars.add(bar);
        }
        controls.addView(meter, new LinearLayout.LayoutParams(-1, px(42)));
        micStatus = text("Ready to speak", 18, MUTED, false); micStatus.setGravity(Gravity.CENTER);
        controls.addView(micStatus, new LinearLayout.LayoutParams(-1, px(45)));
        View divider = new View(this); divider.setBackgroundColor(LINE);
        body.addView(divider, new LinearLayout.LayoutParams(px(1), -1));
        LinearLayout right = column(); right.setPadding(px(28), px(20), px(24), px(24));
        body.addView(right, new LinearLayout.LayoutParams(0, -1, 1f));
        LinearLayout listHeader = row();
        listHeader.addView(text("Saved sounds", 26, WHITE, true), new LinearLayout.LayoutParams(0, px(52), 1f));
        TextView edit = button("Edit List", false); edit.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(18)); edit.setSingleLine(true); edit.setPadding(px(10),0,px(10),0);
        LinearLayout.LayoutParams editSize = new LinearLayout.LayoutParams(px(102), px(48)); editSize.rightMargin = px(12);
        listHeader.addView(edit, editSize);
        edit.setOnClickListener(v -> { stopAudio(); showEditList(); });
        TextView add = button("+ Add Sound", true); add.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(18));
        listHeader.addView(add, new LinearLayout.LayoutParams(px(152), px(48)));
        add.setOnClickListener(v -> { stopAudio(); showAdd(); });
        right.addView(listHeader); space(right, 18);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(false); scroll.setVerticalScrollBarEnabled(true); scroll.setScrollbarFadingEnabled(false);
        right.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout entries = column(); scroll.addView(entries);
        if (sounds.isEmpty()) {
            TextView empty = text("No sounds yet\nTap Add Sound to import or record.", 20, MUTED, false);
            entries.addView(empty, new LinearLayout.LayoutParams(-1, px(140)));
        }
        for (Sound sound : sounds) {
            LinearLayout line = row(); line.setPadding(0, 0, 0, 0);
            clickable(line, SURFACE, LINE, 12, false);
            TextView play = icon("\ue037", 28, TEAL);
            play.setBackground(shape(Color.TRANSPARENT, TEAL, 0, true));
            line.addView(play, new LinearLayout.LayoutParams(px(44), px(44)));
            TextView label = text(sound.name, 20, WHITE, true);
            label.setPadding(px(16), 0, 0, 0); label.setMaxLines(2);
            line.addView(label, new LinearLayout.LayoutParams(0, -1, 1f));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, px(64)); params.bottomMargin = 0;
            entries.addView(line, params); rows.add(label);
            line.setContentDescription("Play " + sound.name); line.setOnClickListener(v -> playSound(sound));
        }
        updateHome();
        FloatingPanelService.sync(this,false);
    }

    private void updateHome() {
        if (!"home".equals(page) || micButton == null) return;
        boolean speaking = speech.live(), playing = player.active() || speech.playing(), recording = speech.recording();
        level = speech.level; recordMilliseconds = speech.milliseconds;
        boolean available = AudioRoutes.outer(this) != null;
        int lit = (speaking || recording) ? Math.min(11, (int) Math.round(level * 66)) : 0;
        String state = speech.message + SpeakingOptions.mode(this) + holdingMic + "|" + (temporaryRecording != null) + "|" + recording + "|" + recordMilliseconds / 1000 + "|" + speaking + "|" + playing + "|" + available + "|" + playingId + "|" + feedback + "|" + lit;
        if (state.equals(lastHomeState)) return;
        lastHomeState = state;
        int mode = SpeakingOptions.mode(this);
        String labelText = recording ? (speech.recordMode() == SpeakingOptions.HOLD ? "放手播放" : "停止並播放") : speaking ? "停止即時傳聲" : mode == SpeakingOptions.HOLD ? "按住說話" : mode == SpeakingOptions.RECORD ? "點按錄音" : "開始即時傳聲";
        micLabel.setText(labelText); micButton.setContentDescription(labelText);
        int accent = recording ? 0xffef5350 : TEAL;
        clickable(micButton, (speaking || recording) ? accent : Color.TRANSPARENT, accent, 0, true);
        micButton.setTextColor((speaking || recording) ? BG : TEAL);
        if (speechAnimating != recording) { speechAnimating = recording; if (recording) HoldFeedback.start(micButton); else HoldFeedback.stop(micButton); }
        micStatus.setText(recording ? "錄音中 " + recordMilliseconds / 1000 + "s / 180s" : !speech.message.isEmpty() ? speech.message : !feedback.isEmpty() ? feedback : playing ? "Playing sound…" : SpeakingOptions.hint(this));
        routeStatus.setText(available ? "Outer speaker" : "Speaker unavailable");
        routeStatus.setTextColor(available ? WHITE : MUTED);
        for (int i = 0; i < bars.size(); i++) bars.get(i).setBackground(shape(i < lit ? TEAL : LINE, 0, 4, false));
        for (int i = 0; i < rows.size(); i++) {
            TextView label = rows.get(i); View line = (View) label.getParent();
            boolean enabled = !speaking && !recording && (!playing || sounds.get(i).id.equals(playingId));
            line.setEnabled(enabled); line.setAlpha(enabled ? 1f : 0.4f);
            ((TextView) ((LinearLayout) line).getChildAt(0)).setText(playing && sounds.get(i).id.equals(playingId) ? "\ue047" : "\ue037");
        }
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (speaking || playing || recording) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
    private boolean acquireFocus() {
        if (hasFocus) return true;
        AudioOwner.claim(this, this::stopAudio);
        hasFocus = audioManager != null && audioManager.requestAudioFocus(focus) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        if (!hasFocus) AudioOwner.release(this);
        if (!hasFocus) toast("Audio is busy; try again"); return hasFocus;
    }
    private void abandonFocus() {
        if (hasFocus && audioManager != null) audioManager.abandonAudioFocusRequest(focus);
        hasFocus = false;
        AudioOwner.release(this);
    }
    private void playSound(Sound sound) { playFile(new File(getFilesDir(), sound.id + ".wav"), sound.id); }
    private void playFile(File file, String id) {
        if (speech != null && speech.busy()) speech.cancel();
        if (live.isActive() || recorder.active()) return;
        if (player.active()) { if (id.equals(playingId)) player.stop(); return; }
        if (!acquireFocus()) return;
        try {
            playingId = id; feedback = "";
            player.play(file, error -> main.post(() -> {
                playingId = ""; if (error != null) { feedback = error; toast(error); } updateHome();
            }));
        } catch (RuntimeException e) { playingId = ""; abandonFocus(); feedback = e.getMessage(); AudioDiagnostics.log(feedback); toast(feedback); }
        updateHome();
    }
    private void stopAudio() {
        if (speech != null) speech.cancelIfOwned(this); speechAnimating = false;
        holdingMic = false; HoldFeedback.stop(micButton); live.stop(); player.stop(); recorder.cancel(); recordEpoch++; abandonFocus(); level = 0;
        if ("add".equals(page) && addRecord != null) {
            addRecord.setText("Record"); saveButton.setEnabled(!importing); saveButton.setAlpha(importing ? .4f : 1f);
            recordInfo.setText("Record up to 180 seconds");
        }
    }
    private boolean microphoneAllowed() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) return true;
        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQUEST); return false;
    }
    private void deleteTemporary() { if (temporaryRecording != null) temporaryRecording.delete(); temporaryRecording = null; }
    private void cleanupTemporary() {
        File[] files = getCacheDir().listFiles((d, name) -> name.startsWith("voice-") || name.startsWith("import-source-") || name.equals("outer-test.wav"));
        if (files != null) for (File file : files) file.delete();
    }
    private void toggleRecording(boolean forSound) {
        if (recorder.active()) { recorder.stop(); if (forSound) addRecord.setText("Finishing…"); return; }
        if (live.isActive() || player.active()) { toast("Stop playback first"); return; }
        if (!microphoneAllowed() || !acquireFocus()) return;
        if (!forSound) deleteTemporary();
        int epoch = ++recordEpoch; recordMilliseconds = 0; feedback = "";
        File file = new File(getCacheDir(), "voice-" + UUID.randomUUID() + ".wav");
        recorder.start(file, new WavRecorder.Listener() {
            public void meter(double rms, long milliseconds) { main.post(() -> {
                if (epoch != recordEpoch) return;
                level = rms; recordMilliseconds = milliseconds;
                if (forSound && "add".equals(page)) recordInfo.setText("Recording " + milliseconds / 1000 + "s / 180s");
                updateHome();
            }); }
            public void done(File completed, String error) { main.post(() -> {
                if (epoch != recordEpoch || isFinishing()) { if (completed != null) completed.delete(); return; }
                abandonFocus(); HoldFeedback.stop(micButton); level = 0;
                if (error != null) { feedback = error; toast(error); }
                if (forSound && "add".equals(page)) {
                    addRecord.setText("Record"); saveButton.setEnabled(true); saveButton.setAlpha(1f);
                    recordInfo.setText(error != null ? error : completed == null ? "Recording cancelled" : "Recorded " + recordMilliseconds / 1000 + "s");
                    if (completed != null) { if (pendingFile != null) pendingFile.delete(); pendingFile = completed; importLabel.setText("Microphone recording.wav"); }
                } else if (completed != null) {
                    holdingMic = false;
                    temporaryRecording = completed;
                    playFile(completed, "temporary");
                } else holdingMic = false;
                updateHome();
            }); }
        });
        if (forSound) { addRecord.setText("Stop Recording"); saveButton.setEnabled(false); saveButton.setAlpha(.4f); }
        updateHome();
    }
    private void showEditList() {
        int scrollY = "edit".equals(page) && editScroll != null ? editScroll.getScrollY() : 0;
        if (editDraft == null) {
            editDraft = new ArrayList<>();
            for (Sound sound : sounds) editDraft.add(new Sound(sound.id, sound.name));
        }
        page = "edit";
        // Keep the editing controls clear of the overlay; saved enable state is retained.
        stopService(new Intent(this, FloatingPanelService.class));
        startPage("Edit Saved Sounds", true);
        LinearLayout content = column(); content.setPadding(px(28), px(14), px(28), px(20));
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        content.addView(text("Rename, reorder or delete sounds. Changes apply when you Save Changes.", 16, MUTED, false),
            new LinearLayout.LayoutParams(-1, px(32)));
        ScrollView scroll = new ScrollView(this); scroll.setScrollbarFadingEnabled(false);
        editScroll = scroll;
        content.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout entries = column(); scroll.addView(entries);
        if (editDraft.isEmpty()) entries.addView(text("No saved sounds in this list.", 22, MUTED, false), new LinearLayout.LayoutParams(-1, px(100)));
        for (int i = 0; i < editDraft.size(); i++) {
            Sound sound = editDraft.get(i);
            LinearLayout line = row(); line.setPadding(px(16), 0, px(12), 0); line.setBackground(shape(SURFACE, LINE, 10, false));
            LinearLayout.LayoutParams lineSize = new LinearLayout.LayoutParams(-1, px(54)); lineSize.bottomMargin = px(6); entries.addView(line, lineSize);
            line.addView(text(String.valueOf(i + 1), 15, MUTED, true), new LinearLayout.LayoutParams(px(36), -1));
            TextView name = text(sound.name, 18, WHITE, true); name.setMaxLines(2);
            line.addView(name, new LinearLayout.LayoutParams(0, -1, 1f));
            for (int direction : new int[]{-1, 1}) {
                TextView arrow = icon(direction < 0 ? "\ue5d8" : "\ue5db", 30, WHITE);
                arrow.setContentDescription((direction < 0 ? "Move up " : "Move down ") + sound.name);
                clickable(arrow, Color.TRANSPARENT, 0, 8, false);
                arrow.setEnabled(i + direction >= 0 && i + direction < editDraft.size()); arrow.setAlpha(arrow.isEnabled() ? 1f : .3f);
                line.addView(arrow, new LinearLayout.LayoutParams(px(38), px(38)));
                arrow.setOnClickListener(v -> {
                    int index = editDraft.indexOf(sound), next = index + direction;
                    if (next >= 0 && next < editDraft.size()) { java.util.Collections.swap(editDraft, index, next); showEditList(); }
                });
            }
            TextView rename = button("Rename", false), delete = button("Delete", false);
            rename.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(16)); delete.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(16));
            rename.setContentDescription("Rename " + sound.name); delete.setContentDescription("Delete " + sound.name);
            delete.setTextColor(0xfff49a97);
            line.addView(rename, new LinearLayout.LayoutParams(px(112), px(38)));
            LinearLayout.LayoutParams deleteSize = new LinearLayout.LayoutParams(px(100), px(38)); deleteSize.leftMargin = px(12); line.addView(delete, deleteSize);
            rename.setOnClickListener(v -> renameDraft(sound));
            delete.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Delete saved sound?")
                .setMessage("Remove \"" + sound.name + "\" from this list? The sound is permanently deleted only after Save Changes.")
                .setNegativeButton("Cancel", null).setPositiveButton("Delete", (dialog, which) -> { editDraft.remove(sound); showEditList(); }).show());
        }
        LinearLayout actions = row(); actions.setGravity(Gravity.RIGHT); space(content, 12);
        TextView cancel = button("Cancel", false), save = button("Save Changes", true);
        actions.addView(cancel, new LinearLayout.LayoutParams(px(180), px(60)));
        LinearLayout.LayoutParams saveSize = new LinearLayout.LayoutParams(px(240), px(60)); saveSize.leftMargin = px(16); actions.addView(save, saveSize);
        content.addView(actions); cancel.setOnClickListener(v -> cancelAdd()); save.setOnClickListener(v -> saveEditList());
        scroll.post(() -> scroll.scrollTo(0, scrollY));
    }
    private void renameDraft(Sound sound) {
        EditText input = new EditText(this); input.setSingleLine(true); input.setText(sound.name); input.selectAll();
        input.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(60)});
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Rename sound").setView(input)
            .setNegativeButton("Cancel", null).setPositiveButton("Rename", null).create();
        dialog.setOnShowListener(unused -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            if (name.isEmpty()) { input.setError("Enter a sound name"); return; }
            sound.name = name; dialog.dismiss(); showEditList();
        }));
        dialog.show();
    }
    private void saveEditList() {
        if (editDraft == null) return;
        ArrayList<Sound> previous = new ArrayList<>(sounds);
        sounds.clear(); sounds.addAll(editDraft);
        if (!persistSounds()) { sounds.clear(); sounds.addAll(previous); toast("Could not save changes"); return; }
        for (Sound old : previous) {
            boolean retained = false; for (Sound current : sounds) if (current.id.equals(old.id)) { retained = true; break; }
            if (!retained) new File(getFilesDir(), old.id + ".wav").delete();
        }
        editDraft = null; showHome();
    }
    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] result) {
        super.onRequestPermissionsResult(request, permissions, result);
        boolean granted = result.length > 0 && result[0] == PackageManager.PERMISSION_GRANTED;
        if (request == MIC_REQUEST) toast(granted ? "Microphone allowed. Hold the button to speak." : "Microphone permission is required");
        if (request == STORAGE_REQUEST) { if (granted) browseFiles(null); else toast("File access denied. You can still record a sound."); }
    }

    private void showAdd() {
        page = "add"; feedback = ""; stopService(new Intent(this, FloatingPanelService.class)); startPage("Add Sound", true);
        LinearLayout form = column(); form.setPadding(px(40), px(20), px(40), px(20));
        root.addView(form, new LinearLayout.LayoutParams(-1, 0, 1f));
        form.addView(text("Button name", 26, WHITE, true)); space(form, 10);
        nameInput = new EditText(this); nameInput.setSingleLine(true); nameInput.setTextColor(WHITE);
        nameInput.setHintTextColor(MUTED); nameInput.setHint("Enter a sound name");
        nameInput.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(24));
        nameInput.setTypeface(Typeface.create(bodyFont, Typeface.BOLD));
        nameInput.setPadding(px(20), 0, px(20), 0); nameInput.setBackground(shape(SURFACE, LINE, 10, false));
        nameInput.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(60)});
        nameInput.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_DONE);
        nameInput.setOnEditorActionListener((view, action, event) -> {
            if (action != android.view.inputmethod.EditorInfo.IME_ACTION_DONE) return false;
            android.view.inputmethod.InputMethodManager keyboard = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (keyboard != null) keyboard.hideSoftInputFromWindow(nameInput.getWindowToken(), 0);
            return true;
        });
        form.addView(nameInput, new LinearLayout.LayoutParams(-1, px(62))); space(form, 20);
        form.addView(text("Import or record", 26, WHITE, true)); space(form, 10);
        LinearLayout sources = row();
        TextView importButton = button("Import Sound", false);
        addRecord = button("Record", false);
        sources.addView(importButton, new LinearLayout.LayoutParams(0, px(64), 1f));
        LinearLayout.LayoutParams recordParams = new LinearLayout.LayoutParams(0, px(64), 1f); recordParams.leftMargin = px(16);
        sources.addView(addRecord, recordParams); form.addView(sources);
        importButton.setOnClickListener(v -> chooseWav()); addRecord.setOnClickListener(v -> {
            if (importing) { toast("Wait for import to finish"); return; } toggleRecording(true);
        });
        importLabel = text("WAV, MP3 and other audio files", 19, MUTED, false);
        LinearLayout imported = row(); imported.addView(importLabel, new LinearLayout.LayoutParams(0, px(76), 1f));
        previewPlay = button("Play", false); previewPlay.setTextColor(TEAL); previewPlay.setBackground(shape(0xff113039, TEAL, 10, false)); previewPlay.setContentDescription("Test imported sound");
        imported.addView(previewPlay, new LinearLayout.LayoutParams(px(160), px(60))); form.addView(imported);
        previewPlay.setOnClickListener(v -> { if (pendingFile != null && !importing && !recorder.active()) playFile(pendingFile, "import-preview"); updatePreview(); });
        updatePreview();
        recordInfo = text("Record up to 180 seconds", 18, MUTED, false);
        form.addView(recordInfo, new LinearLayout.LayoutParams(-1, px(36)));
        form.addView(new View(this), new LinearLayout.LayoutParams(1, 0, 1f));
        LinearLayout actions = row(); actions.setGravity(Gravity.RIGHT);
        TextView cancel = button("Cancel", false); saveButton = button("Add Sound", true);
        actions.addView(cancel, new LinearLayout.LayoutParams(px(238), px(74)));
        LinearLayout.LayoutParams saveParams = new LinearLayout.LayoutParams(px(224), px(74)); saveParams.leftMargin = px(20);
        actions.addView(saveButton, saveParams); form.addView(actions);
        cancel.setOnClickListener(v -> cancelAdd()); saveButton.setOnClickListener(v -> saveSound());
    }
    private void updatePreview() {
        if (!"add".equals(page) || previewPlay == null) return;
        boolean available = pendingFile != null && !importing && !recorder.active();
        if (previewPlay.isEnabled() != available) previewPlay.setEnabled(available);
        previewPlay.setAlpha(available ? 1f : .4f);
        String label = player.active() && "import-preview".equals(playingId) ? "Stop" : "Play";
        if (!label.contentEquals(previewPlay.getText())) previewPlay.setText(label);
    }
    private void importWav(final Uri uri) {
        if (!"add".equals(page) || recorder.active() || importing) return;
        stopAudio();
        // A failed replacement must not leave Play pointing at an earlier, unnamed clip.
        if (pendingFile != null) pendingFile.delete(); pendingFile = null;
        final int epoch = ++importEpoch;
        importing = true; saveButton.setEnabled(false); saveButton.setAlpha(0.4f); importLabel.setText("Importing sound…"); updatePreview();
        new Thread(() -> {
            File source = new File(getCacheDir(), "import-source-" + UUID.randomUUID());
            File copied = new File(getFilesDir(), "pending-" + UUID.randomUUID() + ".wav");
            String error = null;
            try (InputStream input = openWav(uri); FileOutputStream output = new FileOutputStream(source)) {
                if (input == null) throw new java.io.IOException("Cannot open the selected file");
                byte[] bytes = new byte[32768]; int count;
                while ((count = input.read(bytes)) != -1) {
                    if (epoch != importEpoch) throw new java.io.IOException("Import cancelled");
                    output.write(bytes, 0, count);
                }
            } catch (Exception e) { error = e.getMessage() == null ? "Cannot read sound file" : e.getMessage(); }
            if (error == null) try { AudioImport.convert(source, copied, () -> epoch != importEpoch); }
            catch (Exception e) { error = e.getMessage() == null ? "Cannot decode this sound" : e.getMessage(); }
            source.delete();
            final String failure = error;
            main.post(() -> {
                if (epoch != importEpoch || !"add".equals(page) || isFinishing()) { copied.delete(); return; }
                importing = false; saveButton.setEnabled(true); saveButton.setAlpha(1f);
                if (failure != null) { copied.delete(); importLabel.setText(failure); updatePreview(); return; }
                if (pendingFile != null) pendingFile.delete(); pendingFile = copied;
                String filename = "file".equals(uri.getScheme()) ? new File(uri.getPath()).getName() : "Imported sound";
                try (android.database.Cursor cursor = getContentResolver().query(uri, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                    if (cursor != null && cursor.moveToFirst()) filename = cursor.getString(0);
                } catch (Exception ignored) { }
                importLabel.setText(filename); updatePreview();
                AudioDiagnostics.log("Sound imported and converted: " + filename);
                if (nameInput.getText().toString().trim().isEmpty()) nameInput.setText(filename.replaceFirst("(?i)\\.[^.]+$", ""));
            });
        }, "sound-import").start();
    }
    private void saveSound() {
        String name = nameInput.getText().toString().trim();
        if (name.isEmpty()) { nameInput.setError("Enter a button name"); return; }
        if (pendingFile == null || importing || recorder.active()) { toast("Import or record a sound first"); return; }
        stopAudio();
        String id = UUID.randomUUID().toString(); File target = new File(getFilesDir(), id + ".wav");
        if (!pendingFile.renameTo(target)) { toast("Could not save sound"); return; }
        Sound sound = new Sound(id, name); sounds.add(sound);
        if (!persistSounds()) { sounds.remove(sound); target.renameTo(pendingFile); toast("Could not save sound list"); return; }
        pendingFile = null; showHome(); FloatingPanelService.sync(this, false);
    }
    private void cancelAdd() {
        editDraft = null;
        stopAudio(); importEpoch++; importing = false;
        if (pendingFile != null) pendingFile.delete(); pendingFile = null;
        showHome();
        FloatingPanelService.sync(this, false);
    }
    private SharedPreferences preferences() { return getSharedPreferences("sounds", MODE_PRIVATE); }
    private void loadSounds() {
        try {
            JSONArray array = new JSONArray(preferences().getString("items", "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.getJSONObject(i); String id = item.getString("id");
                if (id.matches("[0-9a-f-]{36}") && new File(getFilesDir(), id + ".wav").isFile()) sounds.add(new Sound(id, item.getString("name")));
            }
        } catch (Exception e) { toast("Could not read saved sounds"); }
        File[] leftovers = getFilesDir().listFiles((directory, name) -> name.startsWith("pending-"));
        if (leftovers != null) for (File file : leftovers) file.delete();
    }
    private boolean persistSounds() {
        JSONArray array = new JSONArray();
        try {
            for (Sound sound : sounds) { JSONObject item = new JSONObject(); item.put("id", sound.id); item.put("name", sound.name); array.put(item); }
            boolean stored = preferences().edit().putString("items", array.toString()).commit();
            if (stored) FloatingPanelService.sync(this, true);
            return stored;
        } catch (Exception e) { return false; }
    }
    private void showCredits() {
        page = "credits"; LinearLayout header=startPage("關於及授權", true);
        header.getChildAt(0).setOnClickListener(v->showChecks());
        LinearLayout content = column(); content.setPadding(px(72), px(8), px(72), px(12));
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        TextView title = text("Outer Voice", 72, WHITE, true); title.setGravity(Gravity.CENTER);
        SpannableString styledTitle = new SpannableString("Outer Voice");
        styledTitle.setSpan(new ForegroundColorSpan(TEAL), 6, styledTitle.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        title.setText(styledTitle);
        content.addView(title, new LinearLayout.LayoutParams(-1, px(84)));
        String version = "";
        try { android.content.pm.PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0); version = info.versionName + " (" + info.getLongVersionCode() + ")"; } catch (Exception ignored) { }
        String[][] credits = {{"App version", version}, {"Developer", "Zeca"}, {"Tester", "SL"}, {"Contributors", "Chris, j.Lun"}, {"License", "GPL-3.0 + upstream notices"}};
        for (String[] credit : credits) {
            LinearLayout line = row();
            line.addView(text(credit[0], 24, WHITE, true), new LinearLayout.LayoutParams(0, px(56), 1f));
            TextView value = text(credit[1], 23, WHITE, false); value.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
            line.addView(value, new LinearLayout.LayoutParams(0, px(56), 1f)); content.addView(line);
            View border = new View(this); border.setBackgroundColor(LINE); content.addView(border, new LinearLayout.LayoutParams(-1, px(1)));
            if ("License".equals(credit[0])) { line.setOnClickListener(v -> showLicense()); line.setClickable(true); }
        }
        space(content, 10);
        TextView note = text("Based on Zeekr Shortcut by dts88 (https://github.com/dts88/zeekr-shortcut-car)", 17, MUTED, false);
        note.setAutoLinkMask(android.text.util.Linkify.WEB_URLS); note.setGravity(Gravity.CENTER); content.addView(note);
    }
    private void showLicense() {
        try (InputStream input = getAssets().open("LICENSE.txt")) {
            java.io.ByteArrayOutputStream bytes = new java.io.ByteArrayOutputStream(); byte[] buffer = new byte[4096]; int count;
            while ((count = input.read(buffer)) > 0) bytes.write(buffer, 0, count);
            new AlertDialog.Builder(this).setTitle("Open-source license").setMessage(bytes.toString("UTF-8")).setPositiveButton("Close", null).show();
        } catch (Exception e) { toast("License unavailable"); }
    }
    private InputStream openWav(Uri uri) throws Exception {
        return "file".equals(uri.getScheme()) ? new java.io.FileInputStream(new File(uri.getPath())) : getContentResolver().openInputStream(uri);
    }
    private void chooseWav() {
        // Use the v1.2.2 built-in storage browser directly on head units.
        // The browser keeps all extensions selectable for content-based import.
        browseFiles(null);
    }
    private void browseFiles(File directory) {
        if (recorder.active() || importing || !"add".equals(page)) { toast("Stop recording or wait for import first"); return; }
        String permission = android.os.Build.VERSION.SDK_INT >= 33 ? "android.permission.READ_MEDIA_AUDIO" : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{permission}, STORAGE_REQUEST); return;
        }
        ArrayList<File> entries = new ArrayList<>(); ArrayList<String> labels = new ArrayList<>();
        if (directory == null) {
            addLocation(entries, labels, android.os.Environment.getExternalStorageDirectory(), "Internal storage");
            File[] appLocations = getExternalFilesDirs(null);
            if (appLocations != null) for (File appLocation : appLocations) {
                if (appLocation == null) continue;
                String path = appLocation.getAbsolutePath(); int androidPart = path.indexOf("/Android/");
                if (androidPart > 0) addLocation(entries, labels, new File(path.substring(0, androidPart)), "Storage");
            }
            File[] mounts = new File("/storage").listFiles();
            if (mounts != null) for (File mount : mounts) {
                if (!mount.getName().equals("emulated") && !mount.getName().equals("self")) addLocation(entries, labels, mount, "Storage");
            }
        } else {
            File[] children = directory.listFiles(file -> !file.isHidden());
            if (children != null) {
                java.util.Arrays.sort(children, (a, b) -> a.isDirectory() != b.isDirectory() ? (a.isDirectory() ? -1 : 1) : a.getName().compareToIgnoreCase(b.getName()));
                for (File child : children) { entries.add(child); labels.add((child.isDirectory() ? "Folder: " : "Sound: ") + child.getName()); }
            }
        }
        browseDirectory = directory;
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(directory == null ? "Choose storage" : directory.getAbsolutePath())
            .setItems(labels.toArray(new String[0]), (d, which) -> {
                File selected = entries.get(which);
                if (selected.isDirectory()) browseFiles(selected); else importWav(Uri.fromFile(selected));
            }).setNegativeButton("Cancel", null).setNeutralButton(directory == null ? "Help" : "Up", (d, which) -> {
                if (directory == null) toast("Copy an audio file to Download or USB storage. Record microphone is also available.");
                else browseFiles(directory.getParentFile() != null && directory.getParentFile().canRead() ? directory.getParentFile() : null);
            }).create();
        dialog.show();
        if (entries.isEmpty()) toast(directory == null ? "No readable storage found. You can record a sound instead." : "No folders or sound files here; use Up to choose another location.");
    }
    private void addLocation(ArrayList<File> files, ArrayList<String> names, File file, String name) {
        if (!file.isDirectory() || !file.canRead()) return;
        for (File existing : files) try { if (existing.getCanonicalPath().equals(file.getCanonicalPath())) return; } catch (Exception ignored) { }
        files.add(file); names.add(name + ": " + file.getAbsolutePath());
    }
    private void showAudioSettings() {
        LinearLayout panel = column(); panel.setPadding(px(24), px(8), px(24), px(8));
        TextView volumeLabel = text("", 20, WHITE, true);
        panel.addView(volumeLabel);
        android.widget.SeekBar volume = new android.widget.SeekBar(this);
        volume.setMax(audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        volume.setProgress(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC));
        volumeLabel.setText("System media volume: " + volume.getProgress() + "/" + volume.getMax());
        volume.setEnabled(!audioManager.isVolumeFixed());
        panel.addView(volume, new LinearLayout.LayoutParams(-1, px(44)));
        volume.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            public void onStartTrackingTouch(android.widget.SeekBar v) { }
            public void onStopTrackingTouch(android.widget.SeekBar v) { AudioDiagnostics.log("Media volume requested=" + v.getProgress()); }
            public void onProgressChanged(android.widget.SeekBar v, int value, boolean user) {
                if (user) try { audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, value, 0); } catch (RuntimeException e) { toast("Firmware rejected volume change"); }
                volumeLabel.setText("System media volume: " + audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) + "/" + v.getMax());
            }
        });
        TextView gainLabel = text("車外喇叭數碼增益：+" + SpeakingOptions.prefs(this).getInt("external_db",0) + " dB",20,WHITE,true);
        panel.addView(gainLabel); android.widget.SeekBar gainSlider = new android.widget.SeekBar(this);
        gainSlider.setContentDescription("車外喇叭數碼增益"); gainSlider.setMax(24); gainSlider.setProgress(SpeakingOptions.prefs(this).getInt("external_db",0));
        panel.addView(gainSlider,new LinearLayout.LayoutParams(-1,px(48)));
        gainSlider.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener(){
            public void onStartTrackingTouch(android.widget.SeekBar v){} public void onStopTrackingTouch(android.widget.SeekBar v){}
            public void onProgressChanged(android.widget.SeekBar v,int n,boolean user){if(user)SpeakingOptions.prefs(MainActivity.this).edit().putInt("external_db",n).apply();gainLabel.setText("車外喇叭數碼增益：+"+n+" dB");}
        });
        TextView note = text("0 至 +24 dB · 套用錄音、已儲存聲音及即時傳聲\n數碼放大，含過載限制；系統音量獨立調整。", 17, MUTED, false);
        panel.addView(note, new LinearLayout.LayoutParams(-1, px(60)));
        new AlertDialog.Builder(this).setTitle("Audio settings").setView(panel).setPositiveButton("Close", null).show();
    }
    private void showLiveSettings() {
        LinearLayout content=column();content.setPadding(px(20),px(8),px(20),px(12));
        TextView mode=button("收音模式 · "+LiveCaptureMode.label(LiveAudioConfig.mode(this)),false);
        content.addView(mode,new LinearLayout.LayoutParams(-1,px(52)));
        mode.setOnClickListener(v->{
            String[] keys={"compat","performance","standard"};String[] labels={LiveCaptureMode.label(keys[0]),LiveCaptureMode.label(keys[1])+"（Android 10+）",LiveCaptureMode.label(keys[2])};
            int selected=java.util.Arrays.asList(keys).indexOf(LiveAudioConfig.mode(this));
            new AlertDialog.Builder(this).setTitle("Live 收音模式").setSingleChoiceItems(labels,selected,(d,w)->{
                if(w==1&&android.os.Build.VERSION.SDK_INT<29){toast("低延遲傳聲需要 Android 10 或以上");return;}
                SpeakingOptions.prefs(this).edit().putString("live_capture_mode",keys[w]).apply();mode.setText("收音模式 · "+LiveCaptureMode.label(keys[w]));d.dismiss();
            }).setNegativeButton("取消",null).show();
        });
        String selectedMic;
        try { selectedMic=LiveAudioConfig.label(LiveAudioConfig.input(this),0); } catch(RuntimeException e) { selectedMic="已存麥克風離線 · 請重新選擇"; }
        space(content,8);TextView microphone=button("Live 麥克風 · "+selectedMic,false);
        microphone.setTextSize(TypedValue.COMPLEX_UNIT_PX,px(17));microphone.setSingleLine(true);microphone.setEllipsize(android.text.TextUtils.TruncateAt.END);
        content.addView(microphone,new LinearLayout.LayoutParams(-1,px(52)));
        microphone.setOnClickListener(v->{
            java.util.List<android.media.AudioDeviceInfo> ports=LiveAudioConfig.inputs(this);String[] labels=new String[ports.size()+1];labels[0]="自動 · 系統選擇麥克風";
            String key=SpeakingOptions.prefs(this).getString("live_input","");int selected=0;
            for(int i=0;i<ports.size();i++){labels[i+1]=LiveAudioConfig.label(ports.get(i),i+1);if(LiveAudioConfig.info(ports.get(i)).key().equals(key))selected=i+1;}
            new AlertDialog.Builder(this).setTitle("Live 麥克風 · 按 ID／輸入埠辨認").setSingleChoiceItems(labels,selected,(d,w)->{
                LiveAudioConfig.select(this,w==0?"":LiveAudioConfig.info(ports.get(w-1)).key());microphone.setText(w==0?labels[0]:labels[w]);d.dismiss();
            }).setNegativeButton("取消",null).show();
        });
        TextView gainLabel=text("Live 麥克風數碼增益：+"+SpeakingOptions.prefs(this).getInt("live_mic_db",0)+" dB",18,WHITE,true);content.addView(gainLabel);
        android.widget.SeekBar slider=new android.widget.SeekBar(this);slider.setContentDescription("Live 麥克風數碼增益");slider.setMax(24);slider.setProgress(SpeakingOptions.prefs(this).getInt("live_mic_db",0));content.addView(slider,new LinearLayout.LayoutParams(-1,px(48)));
        slider.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(android.widget.SeekBar v){}public void onStopTrackingTouch(android.widget.SeekBar v){}public void onProgressChanged(android.widget.SeekBar v,int n,boolean user){if(user)SpeakingOptions.prefs(MainActivity.this).edit().putInt("live_mic_db",n).apply();gainLabel.setText("Live 麥克風數碼增益：+"+n+" dB");}});
        content.addView(text("收音模式及麥克風選擇在下次開始時生效。\n無聲時請檢查麥克風選擇及輸入電平。",16,MUTED,false));
        TextView details=text(LiveMicPassthrough.lastReport,15,MUTED,false);details.setTextIsSelectable(true);content.addView(details);
        ScrollView scroll=new ScrollView(this);scroll.addView(content);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Live 麥克風設定").setView(scroll).setPositiveButton("關閉",null).create();
        Runnable refreshDetails=new Runnable(){public void run(){if(!dialog.isShowing())return;details.setText(LiveMicPassthrough.lastReport);main.postDelayed(this,1000);}};
        dialog.setOnDismissListener(d->main.removeCallbacks(refreshDetails));dialog.show();main.post(refreshDetails);
    }
    private void showDiagnostics() {
        String report = AudioDiagnostics.report(this);
        ScrollView scroll = new ScrollView(this); TextView content = text(report, 16, WHITE, false);
        content.setTextIsSelectable(true); content.setPadding(px(16), px(8), px(16), px(8)); scroll.addView(content);
        new AlertDialog.Builder(this).setTitle("Audio diagnostics").setView(scroll).setPositiveButton("Close", null)
            .setNeutralButton("Copy report", (dialog, which) -> {
                android.content.ClipboardManager clipboard = (android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Outer Voice audio report", report)); toast("Report copied");
            }).show();
    }
    private void toast(String message) { Toast.makeText(this, message == null ? "Operation failed" : message, Toast.LENGTH_LONG).show(); }
    @Override public void onBackPressed() { if("buttons".equals(page)||"checks".equals(page)){showSettings();return;}if("credits".equals(page)){showChecks();return;}if("settings".equals(page)){showHome();return;}if (!"home".equals(page)) cancelAdd(); else { stopAudio(); super.onBackPressed(); } }
    @Override protected void onResume() { super.onResume(); paused = false; main.removeCallbacks(refresh); main.post(refresh); if ("home".equals(page)||"buttons".equals(page)||"settings".equals(page)||"checks".equals(page)) FloatingPanelService.sync(this, false); settingsRefreshedAt=0; updateSettings(); SmartButtonsService.resume(this); }
    @Override protected void onPause() { paused = true; main.removeCallbacks(refresh); if (live != null) { stopAudio(); deleteTemporary(); if ("add".equals(page) && addRecord != null) { addRecord.setText("Record"); saveButton.setEnabled(!importing); saveButton.setAlpha(importing ? .4f : 1f); recordInfo.setText("Record up to 180 seconds"); } } super.onPause(); }
    @Override protected void onDestroy() { importEpoch++; if (live != null) stopAudio(); if (speech != null) speech.observers.remove(speechChanged); deleteTemporary(); main.removeCallbacksAndMessages(null); if (pendingFile != null) pendingFile.delete(); super.onDestroy(); }
}
