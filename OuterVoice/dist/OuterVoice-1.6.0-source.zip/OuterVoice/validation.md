# Build and validation

Latest release: **v1.4.0, build 8**, Android 9/API 28 minimum. Earlier sections below retain historical evidence; the v1.4.0 section at the end records the approved simulator changes.

Deliverable: OuterVoice-1.1.0.apk, version 1.1.0 (2), package com.zecadev.outervoice, Android 9/API 28 minimum. APK size: 738441 bytes.

SHA-256: `f3ee54d1c0ead97d5f6a697bcdfa30516fe58c33033ef023af23e644baf70d60`.

The final APK passed apksigner verification with a v3 signature and zipalign verification. Signing certificate SHA-256: `664b72c9d4c6075814ffa1c9b72a2d0c78132238fbed9d6b2265b78a7614a17e`.

Pure Java WAV parser tests passed for valid mono/stereo PCM16 and padded ancillary chunks. Tests rejected float, 24-bit, unsupported channel counts, incorrect WAVE signatures, truncated or overflowing chunks, unaligned PCM and invalid byte rates.

Additional pure Java tests passed for recorded WAV headers and metadata, silent PCM, WAV normalization's ×16 ceiling, full-scale signed samples, clipping bounds and invalid PCM byte lengths.

Android 9 checks retained from v1.0.0 include actual Android document-picker import, scrolling, persistence, and microphone permission handling. The final v1.1.0 APK was installed over the earlier version; saved sounds remained. Both Record & Play and Add Sound recording created WAVs verified by reading actual app files: 44100 Hz, one channel, 16-bit samples and nonzero frame counts. This verifies format and capture operation; the emulator microphone data is not proof of real speech quality. Temporary Play rejected missing BUS12, and changing modes removed its cache WAV. Add recording was named and saved. Remove was tested with Cancel and then confirmation; both the saved index and WAV were removed.

With DocumentsUI and MusicPicker disabled, Import WAV automatically opened the local browser after runtime storage permission. The browser rejected invalid.wav and imported welcome.wav. The disabled test-emulator packages were restored. The volume panel, default 100% live level, test-tone missing-route rejection, diagnostic report/copy action and updated Credits version 1.1.0 (2) passed UI checks. No AndroidRuntime fatal crash was recorded. UIAutomator intermittently returned null accessibility roots; those checks were retried/resumed and successful screens were captured. This was a test-service issue, not an observed app crash. Evidence and check scripts are in `qa/`.

Lifecycle checks also passed: leaving the foreground removed the temporary clip and disabled its Play button; Back from an active Add recording discarded that capture; removal stayed effective after restart while earlier saved sounds remained. The media slider changed the emulator's system volume from 5/15 to 15/15 and then restored 5/15, with readback reflected in the panel.

The public wording cleanup was rebuilt with the same version and signing certificate. Focused checks passed for APK update installation, retained sounds, neutral audio-panel wording, media-volume readback and the requested Credits. The APK hash above and affected audio-panel evidence were refreshed. No audio-routing behaviour changed in this cleanup.

The final native screens were compared against the approved mockups at 1024 × 600; see design-qa.md. Test WAVs were imported into the emulator and are not bundled in the APK. A fresh installation starts with an empty sound list.

Hardware validation required: microphone selection and capture, exposure of BUS12_OUTER_NOTIFY to this app, audible outer-speaker output for live speech and WAVs, latency, acoustic feedback, route-loss behavior and active audio-focus interactions. The emulator cannot establish these results. The code requests only BUS12_OUTER_NOTIFY and rejects an unavailable route rather than intentionally falling back to another speaker.

On the head unit, install over v1.0.0, open the header speaker icon, check media volume/live level, and try Test speaker, a WAV and live speech. If still silent, use Diagnostics / Copy report to capture actual device routing and levels. The system media slider is not a verified vendor BUS12 amplifier control. Retain the local signing key and password privately for future app updates. See routing-investigation.md for output settings and the remaining uncertainty.

## v1.1.1 — hold and release speaking

- Removed the Record & Play mode and separate Play control. Live Speaking records while held, finalizes its WAV on release and immediately requests playback using the existing BUS12 WAV player.
- Renamed the Add Sound form submission button to Add Sound. Removed the obsolete live passthrough gain slider.
- Pure Java WAV validation/writer/normalization tests pass. Android Java/DEX/resource compilation, signing verification and ZIP alignment pass, using the retained signing certificate.
- Android 9 emulator check-v111.py verifies the single Live Speaking control, a non-empty 44.1 kHz mono PCM16 WAV after a 2.2-second hold, automatic playback request (BUS12 absent in emulator), Add Sound form recording and label, and temporary-file removal on backgrounding.
- Audible outer-speaker playback remains a vehicle validation step. Historical v1.1.0 emulator scripts and evidence describe the former UI.

## v1.2.0 — floating sound panel (2026-10-06)

Implemented the approved revised first mockup as a native Android settings Activity and a separate foreground overlay Service. The home header's layered-squares icon opens Floating Buttons.

### Passed checks

- Java WAV validation, writer and normalization tests; native resource, Java and DEX compilation; APK signature verification and alignment. Same signer certificate as previous updates: SHA-256 `664b72c9d4c6075814ffa1c9b72a2d0c78132238fbed9d6b2265b78a7614a17e`.
- Upgrade retained all five existing emulator sound fixtures. Default size is 88 physical pixels. Seven named light colors include Light Red; three icon choices represent Angry, Thank You and Warmly Remind. Final 1024 × 600 settings screenshot inspected; icon labels and color choices are visible.
- Real Android permission flow: app showed the Display over other apps explanation, opened the package's Android permission screen, and showed the overlay after Allow display over other apps was enabled and the user returned.
- System `dumpsys window` reports `ty=APPLICATION_OVERLAY`. Actual screenshots show the panel above the separate Android Settings app while Outer Voice's Activity is backgrounded. Foreground service notification is present.
- Color, icon, selection and order persistence. Test order: Welcome, Thank you, Please wait; Thank you configured Light Red + Angry. Only selected sounds are included after the fixed-left Live Speak button.
- Size slider changed actual circle diameter to 144 px (panel measured 712 × 212 px with three selected sounds). Reset restored 88 px (panel 488 × 156 px). Preview is scaled; the overlay uses physical pixels.
- Dragging the dedicated handle moved the system window. Saved coordinates were restored after close/re-enable. Close persisted disabled state, removed the overlay and stopped its Service. The Enable floating panel checkbox also removed it after Save Settings.
- Floating Live Speak captured microphone PCM during a hold, finalized a valid 44.1 kHz mono PCM16 WAV on release, and immediately requested playback via the existing BUS12 WAV player. The emulator lacks BUS12, so the unavailable-route result and temporary-clip cleanup were verified. Saved-sound tap requests playback through the same route.
- Cancelling a held gesture discarded the unfinished WAV and suppressed playback; a normal close click then disabled the panel. Main-screen hold/release and Add Sound recording/cancel regression checks also ran on v1.2.0.
- No AndroidRuntime application crash in the final suite. UIAutomator's intermittent null-root errors were retried; they are automation failures rather than app crashes.

### Evidence and limits

`qa/check-v120.py` contains the initial permission phases and repeatable final suite. `qa/check-v111.py 1.2.0` runs the existing main-screen regression on the new APK. Screenshots include `v120-final-settings.png`, `v120-android-overlay-permission.png`, `v120-panel-144-over-settings.png`, `v120-panel-moved.png`, `v120-panel-live-release.png`, and `v120-final-panel-over-settings.png`.

These checks use the local Android 9 emulator, not the vehicle. Audible BUS12 output, vendor overlay policy and newer-Android foreground microphone behavior need device validation. Android can hide overlays over protected system screens. An enabled panel is restored when Outer Voice is opened, not automatically at device boot.

## v1.2.1 — safer saved-sound editing (2026-10-06)

- Confirmed CarPiano's architecture is preserved: MainActivity opens the floating controls; FloatingPanelService creates a genuine TYPE_APPLICATION_OVERLAY on the default head-unit display. Outer Voice declares SYSTEM_ALERT_WINDOW and checks Display over other apps authorization. MainActivity itself is a normal application window, as in CarPiano.
- Removed home-list trash icons and their deletion handlers. Added Edit List with Rename, up/down ordering controls and text Delete buttons. Deletion requires confirmation and remains staged until Save Changes. Cancel and Back discard the draft. Edit operations preserve the scroll position.
- Pure Java WAV tests, native compilation, signature and alignment verification pass with the existing certificate. v1.2.1 (versionCode 5) retains the saved sounds across upgrade.
- Android 9 emulator regression `qa/check-v121.py` passed: no home trash controls; draft rename/reorder/deletion plus Cancel retains the original names/order/WAV; saved rename/order survive process restart; sound UUID and SHA-256 of recorded audio remain unchanged after rename.
- A selected disposable sound's rename retained its floating selection, color and icon. Confirmed deletion plus Save Changes removed its WAV and removed it from the overlay. All five original emulator fixtures were retained.
- Final screenshot and system-window inspection again confirmed the panel above Android Settings in v1.2.1. No AndroidRuntime application crash was reported. Intermittent UIAutomator null-root responses were retried.
- Visual evidence: `qa/v121-home.png`, `qa/v121-editor.png`, `qa/v121-renamed-overlay.png` and `qa/v121-after-delete-overlay.png`. Audible BUS12 output and vehicle-specific display policy remain hardware checks.

## v1.2.2 — reorderable Live Speak (2026-10-06)

- Pure Java WAV tests, native compilation, APK signature and alignment checks pass, retaining the existing update certificate (versionCode 6).
- Android 9 emulator check-v122.py passes legacy preference migration, default 50% enlargement, locked microphone icon, ordering among saved sounds, and preserved saved-sound settings.
- Empty and out-of-range percentage values block saving. Actual overlay glyph heights are 30px at 0% and 46px at 50%; 100% is approximately twice the baseline. Circle geometry and saved-sound pixels remain unchanged.
- 100% and position persist after restart. Final configuration restores 50% with Live Speak in third position. Holding/releasing it above Android Settings finalizes a 44.1kHz mono PCM16 WAV, requests BUS12 playback, and cleans the temporary clip. No AndroidRuntime crash was reported.
- Audible BUS12 output still requires the vehicle; emulator verifies recording and routing requests only.

## v1.3.0 — larger Live Speak, minimize and broad imports (2026-10-08)

- Pure Java WAV and PCM import tests pass: PCM8/16/24/32, float32/64, downmixing, resampling/amplitude, cancellation cleanup, malformed/truncated inputs. Native compilation, alignment and APK signing pass using the existing certificate (versionCode7).
- Android9 system-window and screenshot checks confirm the whole Live Speak circle is132px at an88px base and50% enlargement. Other circles remain88px. Edge spacing matches12px. At144px base,100% enlargement and zero gaps, Live Speak is288px with proportional icons and no clipping.
- Minimize produces a60px draggable bubble while retaining enabled state. Dragging the bubble does not record; tapping restores the original full-panel frame. Values persist across restart. Hold/release after resizing finalizes PCM16 WAV and requests BUS12 playback.
- Exit disables the overlay, stops its service and closes the app task.
- UI inspection retries transient Android null-root responses and rejects stale snapshots. The Play label now updates only when its state changes, avoiding continuous accessibility events.
- Audio import matrix passes PCM8/24/float WAV, MP3, AAC/M4A, FLAC, OGG, a245-second WAV over20MB, and MP3 content with a.bin extension. Converted headers/duration and enabled Play controls are verified; previews request BUS12. Damaged audio reports an error and disables Play. All five original saved sounds remain unchanged; canceled drafts remove pending/source files; no AndroidRuntime crash is reported. Audible BUS12 playback and device-specific codecs still require the head unit.
- The AAC duration regression revealed Android9 extractor metadata with encoder-delay45158 for a2-second LC-AAC fixture. Import disables decoder gapless trimming to avoid losing audio; codec priming/padding is retained. Decoder source/output formats are recorded in diagnostics.
- Replacing an imported clip clears the previous pending clip first, so a failed replacement cannot leave Play targeting stale audio.
- The final UI check verifies visible settings helper text, the home touch/ripple and Exit controls, and minimized-state restart/reopen across status-bar and fullscreen screens. Overlay windows use absolute screen coordinates to avoid24px inset shifts.
- Failed replacement after a successful MP3 import is tested: stale pending audio is removed and Play becomes disabled. The draft cancels cleanly. Final48px percentage input and preview label padding are checked in the rebuilt APK.

## v1.4.0 — approved UI revisions (2026-10-09)

Final signed APK: `dist/OuterVoice-1.4.0.apk`, version 1.4.0 (8), 771212 bytes. SHA256: `d457dd140c4c0d51851a95b796333d3a23cc70f437608455dcd53ac9ef40dc22`. Signature and alignment pass with the retained certificate `664b72c9d4c6075814ffa1c9b72a2d0c78132238fbed9d6b2265b78a7614a17e`. Update installation succeeds on Android 9 with existing saved sounds retained.

Pure Java WAV parser/writer/normalization and PCM import tests pass. New header checks cover mono/stereo rates from 8–192 kHz. Android microphone capture chooses a supported format instead of requiring 44.1 kHz mono PCM16 input. Emulator diagnostics verify 48000 Hz, two channels and float capture (`input encoding=4`); actual recorded files contain nonzero PCM16 WAV frames at the captured rate/channel count. PCM16 remains the storage format used by the existing player. The 180-second cap remains.

Native acceptance checks at 1024 × 600 verify:

- Two Floating Panel tabs, six visible ordering entries, warm-to-cool ten-color palette, separate default App Blue option, fixed Live Speak microphone, twelve icon choices, enlargement moved above minimized size, and settings/previews fitting without a settings scrollbar. Draft values survive tab switches; Cancel preserves the original preferences exactly.
- Persisted custom Live Speak color, icon and minimized size; real `APPLICATION_OVERLAY` windows above Android Settings on display 0. Idle auto-minimize and multi-button reopen work. A 5-second timeout cannot interrupt a 9-second hold, and the panel minimizes after release.
- Separated toolbar controls, close confirmation/Cancel, manual minimize/reopen, saved positions and minimized state across process restart. With only Live Speak selected, the bubble records directly without expanding; dragging cancels and persists its new position.
- The final position correction anchors each minimize to Live Speak's center. With Android animations enabled, native manual, moved-panel and reordered-button checks match the expected bubble window exactly. A previously dragged bubble does not override the next anchor. The single-button panel auto-minimizes at its centered microphone position. Browser DOM measurements also match before/after centers exactly for reordered Live Speak: (474.6215, 415.4978) viewport pixels.
- Maximum 144 px base/100% enlargement produces a 288 px Live Speak circle; separate minimized size reaches 144 px. The animation-enabled pixel check measures a 132 px button pulsing through widths including 116 px, then returning to 132 px. Disabled system animations use the static halo; the test restores the emulator animation setting.
- Live Speak is reordered from third to first. With all six buttons selected, the maximum-width overlay is 1008 × 446 px above Android Settings. Its Minimize control fills the available toolbar width, sounds scroll horizontally, and minimize/reopen restores its full frame.
- Add Sound has a clear 60 px Play control, no duplicate Browse action and no fixed capture specification. A disposable sixth recorded sound confirms all six Home/Edit rows fit. Confirmed deletion remains staged until Save Changes, removes only that fixture and preserves all five originals. Exit disables the overlay and removes the active service/task; service removal was verified after its asynchronous shutdown.
- The final APK imports 48 kHz stereo PCM24 WAV, MP3 and MP3 content with a `.bin` extension, converts to the playback format and enables Play. Preview requests reject missing BUS12 clearly. A damaged WAV disables Play and reports the decoder error. Cancel removes pending imports and preserves existing sounds. Android picker packages are restored after testing.

Import regression exposed Android's generic GET_CONTENT fallback resolving to an images-only gallery. The final build uses OPEN_DOCUMENT for any extension and opens the built-in file browser directly if that picker is absent; the corrected fallback is exercised above. No AndroidRuntime fatal crash is observed.

Evidence: `qa/check-v140.py`, `qa/check-v140-extra.py`, `qa/check-v140-anchor.py`, native/browser `qa/v140-*` PNG/XML snapshots and the approved `web-simulator/` reference. Android 9 accessibility sometimes omits non-focusable overlays or returns null/idle errors; tests use window geometry and retry fresh snapshots. Continuously updating recording status is stopped before idle snapshots, and Exit allows a bounded service-shutdown wait.

Physical head-unit checks remain necessary for audible BUS12 output, microphone quality, firmware routing/codec support, latency, feedback and newer-Android permission behavior. The emulator verifies capture and playback requests, not external amplifier sound.

## v1.4.1 — anchored expansion and native picker compatibility (2026-10-10)

Signed APK `dist/OuterVoice-1.4.1.apk`, version 1.4.1 (9), 775305 bytes, SHA256 `9f86edff58ac6e739ba549ccb82173d0511204d0d5665b7e6111500c7078c603`. WAV/normalization/PCM import tests, native compilation, retained-certificate signature and alignment checks pass. Update installation succeeds over the existing emulator app.

- With Live Speak third, minimizing and reopening retain its exact center. After moving the bubble 70px horizontally and 40px vertically, the expanded microphone matches the moved center exactly. The resulting full-panel frame survives a process restart. Near screen edges, the full panel is clamped into the 1024×600 display. A maximum-width horizontally scrolled panel restores both the scroll offset and microphone anchor.
- Both size sliders select 64px and 200px, save correctly and retain their values after restart. The native settings screen fits its scaled previews at the 200px limit. The expanded Live Speak diameter reaches 400px with 100% enlargement; a 200px minimized bubble is verified.
- Import Sound launches Android DocumentsUI's picker outside Outer Voice; cancel returns to Add Sound. With DocumentsUI temporarily unavailable, a disposable arbitrary-file GET_CONTENT picker returns a WAV content URI that imports successfully and enables Play. An images-only gallery is not launched. Without a compatible picker, the explicit availability dialog appears; the built-in storage browser opens only after Browse files is selected.
- All native phases preserve saved-sound preferences exactly, restore original floating/animation/picker state and remove the test-only app. No AndroidRuntime fatal crash is observed. Transient null-root accessibility snapshots are retried.
- Browser verification matches the moved bubble center (507.4448, 379.1052) and expanded Live Speak center (507.4448, 379.1203), within 0.02 viewport pixels. A temporary test tab preserves the user's open settings draft; the original bubble position is restored afterward.

Evidence: `qa/check-v141.py`, `qa/build-picker-probe.py`, `qa/picker-probe/`, and `qa/v141-*` PNG/XML. The emulator's compatible-picker probe validates the legacy intent path, not the head unit's installed file manager. If firmware has no enabled compatible picker, enabling or installing one is required for a native picker. Audible BUS12 output remains a vehicle check.


## v1.4.2 — direct built-in storage browser (2026-10-10)

Signed APK `dist/OuterVoice-1.4.2.apk`, version 1.4.2 (10), 771211 bytes, SHA256 `edef1b40588f2f10a22c8cd1ca500386f2286338439c9dcecc12239f18e04fb7`. WAV validation, normalization, PCM conversion/import tests, native compilation, signature and alignment checks pass. The retained certificate SHA256 is `664b72c9d4c6075814ffa1c9b72a2d0c78132238fbed9d6b2265b78a7614a17e`. Update installation over v1.4.1 preserves saved-sound preferences exactly.

- Import Sound directly opens the app's Choose storage dialog with Android DocumentsUI enabled. Denying file-access permission returns to Add Sound; retrying and allowing access opens the browser. The resumed activity remains Outer Voice. It also opens directly with DocumentsUI disabled.
- Internal storage, Download, a disposable test folder, Up, folder re-entry and Cancel work. The browser lists non-hidden files of every extension.
- PCM24 WAV, MP3 and MP3 content named `.bin` import successfully into 44.1kHz mono PCM16 WAVs of the expected duration. Successful imports enable Play, and preview requests correctly report BUS12 unavailable on the emulator. Invalid `broken.wav` is rejected with Play disabled. Cancel removes pending files.
- Saved-sound preferences remain unchanged across all cases. The original floating preferences, storage permission grant and DocumentsUI state are restored; only the four temporary fixture copies and their test folder are removed. No AndroidRuntime fatal crash is observed. Transient null accessibility roots are retried.

Evidence: `qa/check-v142.py`, `qa/v142-*` PNG/XML and the signed APK. Floating-panel positioning and 64–200px configuration code are unchanged from v1.4.1. Mounted USB/external-storage access, newer-Android storage behavior and audible BUS12 output remain actual-head-unit checks.
